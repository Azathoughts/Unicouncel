-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2024 at 04:14 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `unicounsel`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(255) NOT NULL,
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'student',
  `SQ` varchar(50) DEFAULT NULL,
  `SQA` varchar(50) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `firstname`, `lastname`, `email`, `username`, `password`, `role`, `SQ`, `SQA`, `enabled`) VALUES
(32, 'Russell', 'Barro', 'russellbarroa@gmail.com', 'Azathoughts', '25d55ad283aa400af464c76d713c07ad', 'admin', 'SQ1', 'b8c10bc040834b4f8390b51ad179fd44', 1),
(33, 'Russell', 'Barro', 'aaa@gmail.com', 'dq', '25f9e794323b453885f5181f1b624d0b', 'student', 'SQ1', 'b8c10bc040834b4f8390b51ad179fd44', 0),
(34, 'Russell', 'Miko', 'russellbarro@gmail.com', 'Azathought', 'e807f1fcf82d132f9bb018ca6738a19f', 'guidance_counselor', 'Nickname', 'b8c10bc040834b4f8390b51ad179fd44', 1),
(35, 'Russell', 'Barro', 'russellabarro@gmail.com', 'ali', 'f5bb0c8de146c67b44babbf4e6584cc0', 'guidance_counselor', 'Nickname', 'b8c10bc040834b4f8390b51ad179fd44', 1),
(36, 'Cholene Jane', 'Aberin', 'cholenejaneaberin@gmail.com', 'cholenejane', '21aad889867d422f00bb4bb4c9830fbf', 'student', 'SQ1', '28198b369067e88dab9fefe85484dbf4', 1),
(37, 'Russell', 'Miko', 'aaa@vvv', 'kbkhjb', '25d55ad283aa400af464c76d713c07ad', 'student', 'SQ1', 'b8c10bc040834b4f8390b51ad179fd44', 1),
(38, 'Russell', 'Barro', 'kserrano497@gmail.com', 'aliI', '25f9e794323b453885f5181f1b624d0b', 'student', 'SQ1', 'b8c10bc040834b4f8390b51ad179fd44', 1),
(39, 'Cholene', 'Aberin', 'cholenejaneaberin@gmail.com', 'cholene123', '6f7da4dd8cd0a863d9d233f88755be5a', 'guidance_counselor', 'Birthplace', '8f77ef405b018aede9a30adef6e324a3', 1),
(40, 'Amador', 'Obal', 'amadorobal@gmail.com', 'amador', '927b4997d47cf8dc91649df353cc7e20', 'student', 'SQ1', 'd0f9230d9dc78d1eb0b048d6c9ca7acd', 1),
(41, 'Cholene', 'Aberin', 'das@g.s', 'choleneee', 'ed60f6cbe639cb25edf814466696c4c0', 'student', 'SQ1', 'd8578edf8458ce06fbc5bb76a58c5ca4', 1),
(42, 'Isidoro', 'Luciano', 'isidoroaberin@gmail.com', 'isidoroa', 'b48fc75edb1027882cde556f308cc449', 'guidance_counselor', 'Nickname', '998511b1041c9d3ab2925bbb0c567b64', 1),
(43, 'Dory', 'Obal', 'doryaberin@gmail.com', 'dory123456789', '714f47f0eaea51136aa57a58ba1d72d9', 'Student', 'Nickname', 'd48b3e85644a4f510e6702a12e0951c2', 1),
(44, 'CJ', 'Obal', 'cholene@gmail.com', 'cholene12345678', '35b58934aa04451e683a51912b9d5c65', 'student', 'Nickname', '813c19ca426e2f221b0216fb45b10e4c', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cancelled_table`
--

CREATE TABLE `cancelled_table` (
  `user_id` int(11) NOT NULL,
  `id` int(255) NOT NULL,
  `priority` varchar(30) DEFAULT NULL,
  `student_name` varchar(100) DEFAULT NULL,
  `student_number` int(15) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time NOT NULL DEFAULT current_timestamp(),
  `program` varchar(50) DEFAULT NULL,
  `year` int(1) DEFAULT NULL,
  `section` varchar(1) DEFAULT NULL,
  `contactnumber` int(11) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `comment` varchar(300) DEFAULT NULL,
  `communication` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `college`
--

CREATE TABLE `college` (
  `college_id` int(11) NOT NULL,
  `college_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `college`
--

INSERT INTO `college` (`college_id`, `college_name`) VALUES
(1, '[CLAS] College of Liberal Arts and Sciences'),
(2, '[CBA] College of Business and Accountancy'),
(3, '[COE] College of Education'),
(4, '[COC] College of Criminology'),
(5, '[COL] College of Law'),
(6, '[GS] Graduate School');

-- --------------------------------------------------------

--
-- Table structure for table `history_table`
--

CREATE TABLE `history_table` (
  `user_id` int(11) NOT NULL,
  `id` int(255) NOT NULL,
  `priority` varchar(30) DEFAULT NULL,
  `student_name` varchar(100) DEFAULT NULL,
  `student_number` int(15) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time NOT NULL DEFAULT current_timestamp(),
  `program` varchar(50) DEFAULT NULL,
  `year` int(1) DEFAULT NULL,
  `section` varchar(1) DEFAULT NULL,
  `contactnumber` int(11) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `comment` varchar(300) DEFAULT NULL,
  `communication` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `history_table`
--

INSERT INTO `history_table` (`user_id`, `id`, `priority`, `student_name`, `student_number`, `date`, `time`, `program`, `year`, `section`, `contactnumber`, `email`, `comment`, `communication`) VALUES
(0, 20, 'Emergency', 'Amador Obal', 20221234, '2024-06-06', '09:18:00', '1', 0, '', 2147483647, 'amadorobal@gmail.com', 'Hello this is a comment.Hello this is a comment.Hello this is a comment.Hello this is a comment.Hello this is a comment.Hello this is a comment.Hello this is a comment.Hello this is a comment.Hello this is a comment.Hello this is a comment.Hello this is a comment.Hello this is a comment.Hello this i', 'In person'),
(0, 21, 'Emergency', 'Elvira', 202201234, '2024-06-01', '12:41:00', '28', 0, '', 2147483647, 'elvie@gmail.com', 'hello', 'Virtual');

-- --------------------------------------------------------

--
-- Table structure for table `login_history`
--

CREATE TABLE `login_history` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `login_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `ip_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_history`
--

INSERT INTO `login_history` (`id`, `user_id`, `login_time`, `ip_address`) VALUES
(4, 32, '2024-05-21 18:23:42', '::1'),
(5, 32, '2024-05-21 19:47:34', '::1'),
(6, 36, '2024-05-21 20:00:47', '::1'),
(7, 32, '2024-05-21 20:05:20', '::1'),
(8, 32, '2024-05-21 20:08:50', '::1'),
(9, 32, '2024-05-21 21:25:50', '::1'),
(10, 32, '2024-05-21 21:28:15', '::1'),
(11, 32, '2024-05-21 21:40:06', '::1'),
(12, 32, '2024-05-21 21:44:39', '::1'),
(13, 32, '2024-05-21 21:46:08', '::1'),
(14, 32, '2024-05-21 21:46:39', '::1'),
(15, 32, '2024-05-21 21:46:58', '::1'),
(16, 39, '2024-05-21 21:48:13', '::1'),
(17, 36, '2024-05-21 21:52:09', '::1'),
(18, 32, '2024-05-21 21:56:34', '::1'),
(19, 39, '2024-05-21 21:58:00', '::1'),
(20, 36, '2024-05-21 21:59:03', '::1'),
(21, 40, '2024-05-25 08:32:38', '::1'),
(22, 40, '2024-05-25 08:37:34', '::1'),
(23, 40, '2024-05-27 09:41:47', '::1'),
(24, 41, '2024-05-28 01:41:43', '::1'),
(25, 40, '2024-05-29 00:59:42', '::1'),
(26, 40, '2024-05-29 01:15:18', '::1'),
(27, 32, '2024-05-29 01:21:10', '::1'),
(28, 42, '2024-05-29 01:31:46', '::1'),
(29, 40, '2024-05-29 01:32:45', '::1'),
(30, 40, '2024-05-29 01:45:04', '::1'),
(31, 42, '2024-05-29 01:45:26', '::1'),
(32, 44, '2024-05-29 05:53:26', '::1'),
(33, 40, '2024-05-29 05:55:21', '::1'),
(34, 40, '2024-05-29 05:58:57', '::1'),
(35, 40, '2024-05-29 06:20:08', '::1'),
(36, 32, '2024-05-29 06:56:39', '::1'),
(37, 42, '2024-05-29 07:43:32', '::1');

-- --------------------------------------------------------

--
-- Table structure for table `pending_table`
--

CREATE TABLE `pending_table` (
  `user_id` int(11) NOT NULL,
  `id` int(255) NOT NULL,
  `priority` varchar(30) DEFAULT NULL,
  `student_name` varchar(100) DEFAULT NULL,
  `student_number` int(15) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time DEFAULT current_timestamp(),
  `program` varchar(50) DEFAULT NULL,
  `year` int(1) DEFAULT NULL,
  `section` varchar(1) DEFAULT NULL,
  `contactnumber` int(11) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `comment` varchar(300) DEFAULT NULL,
  `communication` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pending_table`
--

INSERT INTO `pending_table` (`user_id`, `id`, `priority`, `student_name`, `student_number`, `date`, `time`, `program`, `year`, `section`, `contactnumber`, `email`, `comment`, `communication`) VALUES
(42, 55, 'High', 'Amador Obal', 202201987, '2024-06-06', '13:30:00', '23', 1, 'A', 2147483647, 'amadorobal@gmail.com', 'I\'m seeking for an educational advice.', 'Virtual');

-- --------------------------------------------------------

--
-- Table structure for table `program`
--

CREATE TABLE `program` (
  `program_id` int(11) NOT NULL,
  `college_id` int(50) NOT NULL,
  `program_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `program`
--

INSERT INTO `program` (`program_id`, `college_id`, `program_name`) VALUES
(1, 1, 'BS Psychology'),
(2, 1, 'BS Mathematics'),
(3, 1, 'BS Computer Science'),
(4, 1, 'BS Information System'),
(5, 1, 'BS Information Technology'),
(6, 1, 'BS Entertainment and Multimedia Computing'),
(7, 1, 'Bachelor of Public Administration'),
(8, 1, 'Bachelor of Public Administration (SPECIAL PROGRAM'),
(9, 1, 'BA Communication'),
(10, 1, 'AB Political Science'),
(11, 2, 'Bachelor of Science in Office Administration (BSOAD)'),
(12, 2, 'Bachelor of Science in Accounting Information Technology (BSAIS)'),
(13, 2, 'Bachelor of Science in Accountancy (BSA)'),
(14, 2, 'Bachelor of Science in Tourism Management (BSTM)'),
(15, 2, 'Bachelor of Science in Hospitality Management (BSHM)'),
(16, 2, 'Bachelor of Science in Accounting Bachelor of Science in Business Administration Major in Financial Management (BSBA-FMGT)'),
(17, 2, 'Bachelor of Science in Business Administration Major in Marketing Management (BSBA-MKMGT)'),
(18, 2, 'Bachelor of Science in Entrepreneurial Management (BSEM)\r\n'),
(19, 2, 'Bachelor of Science in Business Administration Major in Human Resource Management (BSBA-HRM)'),
(20, 3, 'Bachelor in Elementary Education Major in Early Childhood Education (BEED EARLY CHILDHOOD EDUCATION)'),
(21, 3, 'Bachelor in Elementary Education Major in Special Education (BEED SPECIAL EDUCATION)'),
(22, 3, 'Bachelor in Secondary Education Major in Technology and Livelihood Education (BSE TLE)'),
(23, 3, 'Bachelor in Secondary Education Major in Science (BSE Science)'),
(24, 3, 'Bachelor in Secondary Education Major in English (BSE English)'),
(25, 3, 'Bachelor in Secondary Education Major in English - Chinese'),
(26, 3, 'Certificate in Professional Education'),
(27, 3, 'Elementary | Secondary | P.E.'),
(28, 4, 'BS Criminology'),
(29, 5, 'College of Law'),
(30, 6, 'Doctor of Public Administration'),
(31, 6, 'PhD Education Management'),
(32, 6, 'Master in Public Administration'),
(33, 6, 'Master in Business Administration'),
(34, 6, 'Master of Arts in Teaching in Early Grades'),
(35, 6, 'Master of Arts in Teaching Science'),
(36, 6, 'MAED-EM'),
(37, 6, 'MS Criminology');

-- --------------------------------------------------------

--
-- Table structure for table `scheduled_table`
--

CREATE TABLE `scheduled_table` (
  `user_id` int(11) NOT NULL,
  `id` int(255) NOT NULL,
  `priority` varchar(30) DEFAULT NULL,
  `student_name` varchar(100) DEFAULT NULL,
  `student_number` int(15) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` time NOT NULL DEFAULT current_timestamp(),
  `program` varchar(50) DEFAULT NULL,
  `year` int(1) DEFAULT NULL,
  `section` varchar(1) DEFAULT NULL,
  `contactnumber` int(11) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `comment` varchar(300) DEFAULT NULL,
  `communication` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `scheduled_table`
--

INSERT INTO `scheduled_table` (`user_id`, `id`, `priority`, `student_name`, `student_number`, `date`, `time`, `program`, `year`, `section`, `contactnumber`, `email`, `comment`, `communication`) VALUES
(40, 23, 'Low', 'Cholene Jane Aberin', 20220187, '2024-05-30', '09:45:00', '4', 2, 'A', 2147483647, 'cholenejaneaberin@gmail.com', 'I am having trouble with my family and it affects my studies.', 'In person');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cancelled_table`
--
ALTER TABLE `cancelled_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `college`
--
ALTER TABLE `college`
  ADD PRIMARY KEY (`college_id`);

--
-- Indexes for table `history_table`
--
ALTER TABLE `history_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_history`
--
ALTER TABLE `login_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_login_user_id` (`user_id`);

--
-- Indexes for table `pending_table`
--
ALTER TABLE `pending_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `program`
--
ALTER TABLE `program`
  ADD PRIMARY KEY (`program_id`);

--
-- Indexes for table `scheduled_table`
--
ALTER TABLE `scheduled_table`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `cancelled_table`
--
ALTER TABLE `cancelled_table`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `history_table`
--
ALTER TABLE `history_table`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `login_history`
--
ALTER TABLE `login_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `pending_table`
--
ALTER TABLE `pending_table`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `program`
--
ALTER TABLE `program`
  MODIFY `program_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `scheduled_table`
--
ALTER TABLE `scheduled_table`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `login_history`
--
ALTER TABLE `login_history`
  ADD CONSTRAINT `fk_login_user_id` FOREIGN KEY (`user_id`) REFERENCES `accounts` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
